

workdir='/Users/xingchong/Documents/workspace/cocospl/planegame'

echo "\nenter planegame path...workdir="$workdir
cd $workdir

echo "\nsign ipa start..."
cd $workdir/publish
rm -rf Payload/planegame.app/_CodeSignature
cp embedded.mobileprovision Payload/planegame.app/embedded.mobileprovision
/usr/bin/codesign -f -vv -s "iPhone Distribution: chong xing" Payload/planegame.app
#/usr/bin/codesign -f -s "iPhone Developer: chong xing (GZA9X2S7AZ)" Payload/planegame.app
echo "sign ipa end..."


echo "\nzip start..."
zip -r Payload.zip Payload
echo "zip finish..\n"

echo "\nrename ipa..."
curdate=$(date '+%Y%m%d%H%M')
ipa_name=plane$curdate.ipa
echo ${ipa_name}
mv Payload.zip "${ipa_name}"


