
workdir='/Users/xingchong/Documents/workspace/cocospl/planegame'


new_code_dir=`dirname $1`/assets/
echo "\nnew_code_dir="$new_code_dir


echo "\nenter planegame path...workdir="$workdir
cd $workdir


echo "\ncopy new file to work dir..."
cp -rf $new_code_dir/cached_res                 $workdir/
cp -rf $new_code_dir/Classes/battle             $workdir/frameworks/runtime-src/Classes/
cp -rf $workdir/shell/backfile/GlobalConfig.lua $workdir/cached_res/script/util/

echo "\nnew file svn ststus...."
svn status $workdir/cached_res
svn status $workdir/frameworks/runtime-src/Classes/


#echo "rm -rf simulator/ios  \n"
#rm -rf $workdir/simulator/ios/planegame*

echo "\ncompile cpp for android..."
cocos compile -p android -m debug


echo "\nrename apk..."
curdate=$(date '+%Y%m%d%H%M')
apk_name=plane$curdate.apk
echo ${apk_name}
mv $workdir/simulator/android/planegame-debug.apk $workdir/simulator/"${apk_name}"


