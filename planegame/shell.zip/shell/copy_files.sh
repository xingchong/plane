
workdir='/Users/xingchong/Documents/workspace/cocospl/planegame'


new_code_dir=`dirname $1`/assets/
echo "\nnew_code_dir="$new_code_dir


echo "\nenter planegame path...workdir="$workdir
cd $workdir


echo "\ncopy new file to work dir..."
cp -rf $new_code_dir/cached_res                 $workdir/
cp -rf $new_code_dir/Classes/battle             $workdir/frameworks/runtime-src/Classes/
cp -rf $workdir/shell/backfile/GlobalConfig.lua $workdir/cached_res/script/util/

echo "\nnew file svn ststus...."
svn status $workdir/cached_res
svn status $workdir/frameworks/runtime-src/Classes/

echo "copy file finish.........."

