
workdir='/Users/xingchong/Documents/workspace/cocospl/planegame'


new_code_dir=`dirname $1`/assets/
echo "\nnew_code_dir="$new_code_dir


echo "\nenter planegame path...workdir="$workdir
cd $workdir


echo "\ncopy new file to work dir..."
cp -rf $new_code_dir/cached_res                 $workdir/
cp -rf $new_code_dir/Classes/battle             $workdir/frameworks/runtime-src/Classes/
cp -rf $workdir/shell/backfile/GlobalConfig.lua $workdir/cached_res/script/util/

echo "\nnew file svn ststus...."
svn status $workdir/cached_res
svn status $workdir/frameworks/runtime-src/Classes/


#echo "rm -rf simulator/ios  \n"
#rm -rf $workdir/simulator/ios/planegame*

echo "\ncompile cpp for ios..."
#cocos compile -p android -m debug
cocos compile -p ios -m release

echo "\ncopy planegame.app"
cp -r $workdir/publish/ios/planegame\ iOS.app $workdir/publish/Payload/planegame.app


cd $workdir/publish

echo "\nsign ipa start..."
rm -rf Payload/planegame.app/_CodeSignature
cp iOS_Team_Provisioning_Profile_.mobileprovision Payload/planegame.app/embedded.mobileprovision
/usr/bin/codesign -f -vv -s "iPhone Distribution: chong xing" Payload/planegame.app
echo "sign ipa end..."


echo "\nzip start..."
zip -r Payload.zip Payload
echo "zip finish..\n"

echo "\nrename ipa..."
curdate=$(date '+%Y%m%d%H%M')
ipa_name=plane$curdate.ipa
echo ${ipa_name}
mv Payload.zip "${ipa_name}"


