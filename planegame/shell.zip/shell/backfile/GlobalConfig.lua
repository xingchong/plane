module(...,package.seeall)

IS_DEBUG             = true
IS_DOWNLOAD_PACKAGE  = true
gamecode  = "xy"


version = {
    client = "0.0.0.3",
    res    = "0.0.0.3",
    server = "0.0.0.3"
}


server = {
--    loginServerIp   = "172.16.3.100" , --"172.16.0.143",  "172.16.0.195", 
--    loginServerPort = 6601,
--    loginServerIp   = "172.16.0.184",  --huangxu
--    loginServerPort =  6601, --8801, 
--      gameServerIp   = "172.16.1.104",   --dulin
--      gameServerPort =  6608,
--    loginServerIp   = "172.16.0.143", --zhangzhiyong
--    loginServerPort =  6601,
--    gameServerIp   = "172.16.0.175", --wanglijun
--    gameServerPort =  6608,

    gameServerIp   = "183.60.69.233",
    gameServerPort = 8008,
    httpServerList ="http://172.16.3.91/ximobile/mbmsdk/?type=serverlist&data={\"pid\":\"ndios\",\"uid\":\"{0}\"}",
    httpServer ="http://172.16.3.91/ximobile/mbmsdk/?type=loginkey&data={\"pid\":\"ndios\",\"uid\":\"{0}\",\"server_id\":\"{1}\",\"token\":\"EF1F081BE5DA4444A82E3047A32F4D7E\"}",
    currentServer = "",
    currentArea   = ""
}


language = {
    currentLanguage = "zh_CN",
    LANGUAGE_CONFIG = ""
}



sdk = {
    LOGIN_SUCCESS_91                    = 400,
    PLATFORM_LOGOUT                     = 401,
    RETURN_GAME                         = 402,
    HTTP_ERROR                          = 403,
    SDK                                 = 405,
    SDK_CHARGE                          = 601,
    SDK_LOGIN                           = 602,
    SDK_DEVICETOKEN                     = 603,
    SDK_PUSHNOTIFICATION                = 604,
    SDK_LOCALNOTIFICATION               = 605
}


PayListUrl = "http://passport.genchance.com/passport/pay/queryrechargepackage.go?gamecode=" .. gamecode
channel    = "appstore"
mtaappkey  = "IMJ5ULQ5W29M"
chargeType = "2"

webURL = "http://res.pokersg.com/pokersg/sb/member/"

gameNeedGuideNewUser = false



