
echo "enter planegame path..."
cd /Users/xingchong/Documents/workspace/cocospl/planegame

#cocos compile -p android -m debug


cd shell
pwd
echo ".....................................\n"

#curdate=$(date '+%Y-%m-%d %H:%M:%S')
curdate=$(date '+%Y%m%d%H%M')
ipa_name=plane$curdate.ipa
echo $ipa_name
echo ${ipa_name}

cp plane1208.zip  "${ipa_name}"






